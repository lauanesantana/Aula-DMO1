package com.example.listview_lauane.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

// Banco de dados Room (Singleton): ponte entre a entidade Curso e o CursoDao
@Database(entities = [Curso::class], version = 1)
abstract class CursoDatabase : RoomDatabase() {

    abstract fun cursoDao(): CursoDao

    companion object {
        @Volatile
        private var INSTANCE: CursoDatabase? = null

        fun getInstance(context: Context): CursoDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    CursoDatabase::class.java,
                    "cursos_database"
                ).build()

                INSTANCE = instance
                instance
            }
        }
    }
}
