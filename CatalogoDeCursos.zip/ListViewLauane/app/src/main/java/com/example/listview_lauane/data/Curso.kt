package com.example.listview_lauane.data

import androidx.room.Entity
import androidx.room.PrimaryKey

// Entidade Room: vira a tabela "curso" no SQLite
@Entity(tableName = "curso")
data class Curso(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,

    val nome: String,
    val descricao: String
)
