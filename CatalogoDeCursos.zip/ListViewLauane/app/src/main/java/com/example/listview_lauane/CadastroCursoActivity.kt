package com.example.listview_lauane

import android.app.Activity
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.listview_lauane.data.Curso
import com.example.listview_lauane.data.CursoDatabase
import com.example.listview_lauane.databinding.ActivityCadastroCursoBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class CadastroCursoActivity : AppCompatActivity() {

    private lateinit var binding: ActivityCadastroCursoBinding
    private lateinit var db: CursoDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCadastroCursoBinding.inflate(layoutInflater)
        setContentView(binding.root)

        db = CursoDatabase.getInstance(this)
        setupListeners()
    }

    private fun setupListeners() {
        binding.btnSalvar.setOnClickListener {
            val nome = binding.edtNome.text.toString().trim()
            val descricao = binding.edtDescricao.text.toString().trim()

            if (nome.isNotBlank() && descricao.isNotBlank()) {
                val novoCurso = Curso(
                    nome = nome,
                    descricao = descricao
                )
                salvarNoBanco(novoCurso)
            } else {
                Toast.makeText(this, "ATENÇÃO: Preencha todos os campos para salvarmos!!!", Toast.LENGTH_SHORT).show()
            }
        }

        binding.btnVoltar.setOnClickListener {
            setResult(Activity.RESULT_CANCELED)
            finish()
        }
    }


    private fun salvarNoBanco(curso: Curso) {
        lifecycleScope.launch(Dispatchers.IO) {
            db.cursoDao().insert(curso)
            setResult(Activity.RESULT_OK)
            finish()
        }
    }
}
