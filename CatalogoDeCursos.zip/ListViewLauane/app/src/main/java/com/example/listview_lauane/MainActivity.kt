package com.example.listview_lauane

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.listview_lauane.data.Curso
import com.example.listview_lauane.data.CursoDatabase
import com.example.listview_lauane.databinding.ActivityMainBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {
    companion object {
        const val TAG = "MainActivity"
    }

    private lateinit var binding: ActivityMainBinding
    private lateinit var adapter: ArrayAdapter<String>
    private lateinit var cursos: MutableList<Curso>
    private lateinit var launcherCadastro: ActivityResultLauncher<Intent>
    private lateinit var db: CursoDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        cursos = mutableListOf()
        db = CursoDatabase.getInstance(this)

        setupViews()
        setupLauncherCadastro()
        setupListeners()
        loadData()
    }

    private fun loadData() {
        lifecycleScope.launch(Dispatchers.IO) {
            var listaDb = db.cursoDao().getAll()

            // primeira vez que o app abre, entao o banco esta vazio
            if (listaDb.isEmpty()) {
                cursosPadrao().forEach { db.cursoDao().insert(it) }
                listaDb = db.cursoDao().getAll()
            }

            withContext(Dispatchers.Main) {
                cursos = listaDb.toMutableList()
                adapter.clear()
                adapter.addAll(cursos.map { it.nome })
                adapter.notifyDataSetChanged()
            }
        }
    }

    // já tinhamos ele
    private fun cursosPadrao(): List<Curso> = listOf(
        Curso(nome = getString(R.string.nome_tsi), descricao = getString(R.string.desc_tsi)),
        Curso(nome = getString(R.string.nome_eng), descricao = getString(R.string.desc_eng)),
        Curso(nome = getString(R.string.nome_ads), descricao = getString(R.string.desc_ads)),
        Curso(nome = getString(R.string.nome_mat), descricao = getString(R.string.desc_mat))
    )

    private fun setupViews() {
        adapter = ArrayAdapter(
            this,
            android.R.layout.simple_list_item_1,
            mutableListOf<String>()
        )

        binding.listaNomes.adapter = adapter
    }


    private fun setupLauncherCadastro() {
        launcherCadastro = registerForActivityResult(
            ActivityResultContracts.StartActivityForResult()
        ) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                loadData()
            }
        }
    }

    private fun setupListeners() {
        binding.listaNomes.setOnItemClickListener { _, _, position, _ ->
            val descricao = cursos[position].descricao
            Toast.makeText(this, descricao, Toast.LENGTH_LONG).show()
        }

        binding.btnAdicionar.setOnClickListener {
            val intent = Intent(this, CadastroCursoActivity::class.java)
            launcherCadastro.launch(intent)
        }
    }
}
