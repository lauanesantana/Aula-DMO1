package com.example.listview_lauane.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query

// DAO: operações que podemos fazer na tabela "curso"
@Dao
interface CursoDao {

    @Insert
    suspend fun insert(curso: Curso)

    @Query("SELECT * FROM curso ORDER BY nome ASC")
    suspend fun getAll(): List<Curso>
}
