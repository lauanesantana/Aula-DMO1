package com.example.listview_lauane

import android.os.Bundle
import android.view.LayoutInflater
import android.widget.ArrayAdapter
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.listview_lauane.databinding.ActivityMainBinding
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    companion object {
        const val TAG = "MainActivity"
    }
    private lateinit var binding: ActivityMainBinding
    private lateinit var adapter: ArrayAdapter<String>
    private lateinit var cursos: Array<String>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // inicializo meu array de cursos que estou puxando la de strings
        cursos = arrayOf(
            getString(R.string.nome_tsi),
            getString(R.string.nome_eng),
            getString(R.string.nome_ads),
            getString(R.string.nome_mat)
        )

        setupViews()
        setupListeners()
    }
    // aqui é meus nomes mesmo de curso
    private fun setupViews() {
        adapter = ArrayAdapter(
            this,
            android.R.layout.simple_list_item_1,
            cursos
        )
        // mantem essa estrutura do pdf do prof
        binding.listaNomes.adapter = adapter
    }
    // aqui é seu eu clico, ele vai abrir meu toast
    private fun setupListeners() {
        binding.listaNomes.setOnItemClickListener { _, _, position, _ ->
            val descricao = when(position) {
                0 -> getString(R.string.desc_tsi)
                1 -> getString(R.string.desc_eng)
                2 -> getString(R.string.desc_ads)
                3 -> getString(R.string.desc_mat)
                else -> ""
            }
            Toast.makeText(this, descricao, Toast.LENGTH_LONG).show()
        }
    }
}