package com.example.conversormoedas

import android.annotation.SuppressLint
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets


        }

        var origemReal = findViewById<Button>(R.id.botaoOrigemReal);
        var destinoDolar = findViewById<Button>(R.id.botaoDestinoDolar);
        var origemDolar = findViewById<Button>(R.id.botaoOrigemDolar);
        var origemEuro = findViewById<Button>(R.id.botaoOrigemEuro);
        var destinoReal = findViewById<Button>(R.id.botaoDestinoReal);
        var destinoEuro = findViewById<Button>(R.id.botaoDestinoEuro);

        var usuarioDigita = findViewById<EditText>(R.id.usuarioDigita);
        var valor = usuarioDigita.text.toString().toDoubleOrNull();

        val valorConvertido = findViewById<TextView>(R.id.valorConvertido);


        var botaoConverter = findViewById<Button>(R.id.botaoConverter);

        origemReal.setOnClickListener {
            destinoDolar.setOnClickListener {
                if (valor != null) {
                    var resultado = valor / 6;
                    valorConvertido.text = String.format("%.2f", resultado);
                }
            }
        }
    }
}


