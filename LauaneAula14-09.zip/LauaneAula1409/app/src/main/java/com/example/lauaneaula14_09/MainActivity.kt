package com.example.lauaneaula14_09

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    //Exercicio: conversão real dolar e euro, conversão entre todos, use image view, mostrando bandeirinha
    companion object {
        const val CONV = "ConversorMoedaActivity"
    }

    private lateinit var tvPrincipal: TextView
    private lateinit var button: Button
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        setupViews()
        setupListeners()
    }

    private fun setupViews() {
        tvPrincipal = findViewById(R.id.tvprincipal)
        button = findViewById(R.id.button)
    }

    private fun setupListeners() {
        button.setOnClickListener {
            emitirMensagem()
        }
    }

    private fun emitirMensagem() {
        tvPrincipal.text = "Que legal!!"
        Toast.makeText(
            this, "Que legal ter você aqui no meu app",
            Toast.LENGTH_LONG
        ).show()
        // ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
        //val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
        //v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
        //insets
    }


}
